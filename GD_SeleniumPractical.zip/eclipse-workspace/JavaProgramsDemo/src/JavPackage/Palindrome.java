package JavPackage;

import java.util.Scanner;

public class Palindrome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the string");
		String s=sc.nextLine();
		
		StringBuffer sb=new StringBuffer(s).reverse();
		String st=sb.toString();
		
		  if(st.equals(s))
		  {
			  System.out.println("String is palindrome");
		  }
		  else
		  {
			  System.out.println("string is not palindrome");
		  }
	}

}
