package PackagePOM;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class OrangeHRMMain {

	
		// TODO Auto-generated method stub
		WebDriver driver;
		
		@BeforeClass
		 void setup()
		{
			driver=new ChromeDriver();
			driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
			driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
			driver.manage().window().maximize();
		}
		
		@Test(priority=1)
		void login()
		{
			PageObjectClassdemo pom=new PageObjectClassdemo(driver);
			pom.setusername("Admin");
			pom.setpassword("admin123");
			pom.submitclick();
		}
		
		@Test(priority=2)
		void image()
		{
			
	          PageObjectClassdemo pom1=new PageObjectClassdemo(driver);
	          
	          pom1.logo();
		}
		
		@AfterClass
		void teardown()
		{
			driver.quit();
		}

	

}
