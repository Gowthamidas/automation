package PackagePOM;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class PageObjectClassdemo {
	WebDriver driver;
	
	//Constructor
	PageObjectClassdemo(WebDriver driver)
	{
		this.driver=driver;
	}
	
	//locator
	By txt_username=By.xpath("//input[@placeholder='Username']");
	By txt_password= By.xpath("//input[@placeholder='Password']");
	By btn_submit=By.xpath("//button[@type='submit']");
	
	
	By logo=By.xpath("//img[@alt='client brand banner']");
	//Action methods
	
	public void setusername(String user)
	{
		driver.findElement(txt_username).sendKeys(user);
	}
	
	public void setpassword(String user)
	{
		driver.findElement(txt_password).sendKeys(user);
	}
	
	public void submitclick()
	{
		driver.findElement(btn_submit).click();
	}
	
	public void logo()
	{
		boolean status=driver.findElement(logo).isDisplayed();
		System.out.println("status of logo is:"+status);
	}
}
