package PackagePOM;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class POMwithPageFactory {
	
	
WebDriver driver;
	
	//Constructor
    POMwithPageFactory(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
    
    //locators
    @FindBy(xpath="//input[@placeholder='Username']")
    WebElement txt_username;
    @FindBy(xpath="//input[@placeholder='Password']")
    WebElement txt_password;
    @FindBy(xpath="//button[@type='submit']")
    WebElement btn_submit;
    
    @FindBy(xpath="//img[@alt='client brand banner']")
    WebElement logo;
    
    //action methods
    
    public void setusername(String user)
	{
    	txt_username.sendKeys(user);
	}
    
    public void setpassword(String user)
	{
		txt_password.sendKeys(user);
	}
    
    public void submitclick()
	{
		btn_submit.click();
	}
}
