package MavenProject2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HiddenDropDemo {

	/**
	 * @param args
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();

		
		//login
		
		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("admin");
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("admin123");
        driver.findElement(By.xpath("//button[normalize-space()='Login']")).click();
		
        driver.findElement(By.xpath("//span[normalize-space()='PIM']")).click();
       
        
        Thread.sleep(5000);
        driver.findElement(By.xpath("(//div[@class='oxd-select-text oxd-select-text--active'])[1]")).click();     
        
        //single element click
        //driver.findElement(By.xpath("//span[normalize-space()='Part-Time Contract']")).click();
        
        //count total options and print it.
        
         List<WebElement> options=driver.findElements(By.xpath("//div[@role='listbox']/*"));
        
		System.out.println("Total Employeement status count is:" +options.size());
		System.out.println("Employeement status options are:");
		for(WebElement op:options)
		{
			System.out.println(""+op.getText());
		}
		
		driver.close();
	}
	
}
