package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptExecutorDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		
		WebElement name=driver.findElement(By.xpath("//input[@id='name']"));
		
		JavascriptExecutor js=(JavascriptExecutor) driver;
		js.executeScript("arguments[0].setAttribute('value','Gowthami')",name);
		
     WebElement start=driver.findElement(By.xpath("//button[@onClick='toggleButton(this)']"));
		js.executeScript("arguments[0].click();",start);
		
		
		//scroll bar testcase
		
		//scroll till specific Pixel
		
		js.executeScript("window.scrollBy(0,3000)");
		
	
		// System.out.println(js.executeScript("return window.pageYOffSet;"));
		
		//2 scroll till element found
		/* WebElement frame=driver.findElement(By.xpath("//td[@class='first columns-cell']"));
     
        js.executeScript("arguments[0].scrollIntoView()",frame);
        
        */
        
        
        js.executeScript("window.scrollBy(0, document.body.scrollHeight)");
        System.out.println(js.executeScript("return window.pageYOffset;"));
        //js.executeScript("window.scrollBy(0, -document.body.scrollHeight)");
        Thread.sleep(5000);
        js.executeScript("document.body.style.zoom='70%';");
        System.out.println(js.executeScript("return document.body.style.zoom"));

        driver.close();
      
	}

}
