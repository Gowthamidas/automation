package MavenProject2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutoSuggestion {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		
		//WebElement iframe=driver.findElement(By.xpath("//iframe[@role='presentation']"));
		
		//driver.switchTo().frame(iframe);
		
		//driver.findElement(By.xpath("//button[@class='M6CB1c rr4y5c']")).click();
         // driver.switchTo().defaultContent();
		
		driver.findElement(By.xpath("//textarea[@id='APjFqb']")).sendKeys("selenium");
		
		List<WebElement> options=driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		System.out.println(" Total found values are:"+options.size());
		
		
		for(int i=0;i<options.size();i++)
		{
			String op=options.get(i).getText();
			
			if(op.equals("selenium"))
			{
				options.get(i).click();
			}
			
		}
		
		/*for(WebElement op:options)
		{
			String opvalue=op.getText();
			if (opvalue.equals("Selenium"))
			{ 
				op.click();
			
			}
	      }
			*/
		
	
		
	}

}
