package MavenProject2;

import java.time.Duration;
import java.util.List;
import java.util.List;
import org.openqa.selenium.StaleElementReferenceException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class SelectDropDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	WebDriver driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	driver.get("https://innovaindia-uat.workingllama.com/atsuser/");
	driver.manage().window().maximize();
	
	//select Dropdown
	WebElement jobtypeDropdown=driver.findElement(By.xpath("//select[contains(@class,'form-control') and @id='search-box-apply-before']"));
	Select Jobtype=new Select(jobtypeDropdown);
	//Jobtype.selectByContainsVisibleText("Contract");
	
	List<WebElement> options=Jobtype.getOptions();
	System.out.println("No fo Job type options are:" +options.size());
	
	
	System.out.println("Job type options are:");
	for (WebElement op:options)
	{
		System.out.println(""+op.getText());
		
	}
	driver.close();
	
	//program2
	driver.get("https://testautomationpractice.blogspot.com/");
	driver.manage().window().maximize();

	WebElement countrydrp=driver.findElement(By.xpath("//select[@class='form-control' and @id='country']"));
	Select countrydrp1=new Select(countrydrp);
	countrydrp1.selectByIndex(7);
	
	
	List<WebElement> countryvalues=countrydrp1.getOptions();
	System.out.println("Country dropdown values are");
	for(WebElement op:countryvalues)
	{
		System.out.println(op.getText());
	}
	
	
	WebElement Colordrp=driver.findElement(By.xpath("//select[@id='colors']"));
	Select Colordrp1=new Select(Colordrp);
	Colordrp1.selectByValue("green");
	
	List<WebElement> ColorOptions=Colordrp1.getOptions();
	System.out.println("Color dropdown values are");
	for(WebElement op1:ColorOptions)
	{
		System.out.println(op1.getText());
	}
	driver.close();
	}

}
