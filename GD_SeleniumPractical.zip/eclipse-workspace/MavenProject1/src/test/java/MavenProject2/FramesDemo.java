package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FramesDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://ui.vision/demo/webtest/frames/");
		//driver.manage().window().maximize();
		
		//Switch to Frame1
		WebElement frame1=driver.findElement(By.xpath("//frame[@src='frame_1.html']"));
		driver.switchTo().frame(frame1);
		
		driver.findElement(By.xpath("//input[@name='mytext1']")).sendKeys("Frame1Input");
		
		//Switch to Frame2
		
		
		driver.switchTo().defaultContent();
		
		WebElement frame2=driver.findElement(By.xpath("//frame[@src='frame_2.html']"));
		driver.switchTo().frame(frame2);
		
		driver.findElement(By.xpath("//input[@name='mytext2']")).sendKeys("Frame2Input");
		
		
		
		//Switch to Frame3
		driver.switchTo().defaultContent();
		
		WebElement frame3=driver.findElement(By.xpath("//frame[@src='frame_3.html']"));
		driver.switchTo().frame(frame3);
		
		driver.findElement(By.xpath("//input[@name='mytext3']")).sendKeys("Programming");
		
		
		driver.switchTo().frame(0);
		
		//driver.findElement(By.xpath("(//div[@class='AB7Lab Id5V1'])[1]")).click();
		
		
		WebDriverWait mywait=new WebDriverWait(driver,Duration.ofSeconds(10));
		//switch to Frame5
		driver.switchTo().defaultContent();
		driver.switchTo().defaultContent();
		WebElement frame5=driver.findElement(By.xpath("//frame[@src='frame_5.html']"));
		driver.switchTo().frame(frame5);
		
		WebElement element=mywait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("https://a9t9.com")));
		
		if (element.isDisplayed() && element.isEnabled()) {
		    element.click();
		} else {
		    System.out.println("Element is not visible or enabled.");
		}
		
		// driver.findElement(By.linkText("https://a9t9.com")).click();
		
		
		
		//WebElement visionimage=driver.findElement(By.xpath("(//img[@alt='Ui.Vision by a9t9 software - Image-Driven Automation'])[1]"));
		//boolean status=visionimage.isDisplayed();
		
		//System.out.println("Vision logo present?" +status);
		
		
	}

}
