package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class MouseActionsDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		//driver.get("https://demo.opencart.com/");
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		 Actions act=new Actions(driver);
		 // Mouse hover action
		 
		/* WebElement components=driver.findElement(By.xpath("//a[text()='Components']"));
		 
		 act.moveToElement(components).click(driver.findElement(By.xpath("//a[text()='Printers (0)']"))).perform();
		 
		*/
		 
		 //double click
		WebElement Copytext=driver.findElement(By.xpath("//button[text()='Copy Text']"));
		 
		 act.doubleClick(Copytext).build().perform();
		 
		//Check Fiel1 coped to Field2 and validate matching
		//approach1
		 /* String Field1Value= driver.findElement(By.xpath("//input[@id='field1']")).getText();
		 
		 String Field2Value=driver.findElement(By.xpath("//input[@id='field2']")).getText();
		 
		 
		 if(Field1Value==Field1Value)
		 {
			 System.out.println("Fiel1 copied to Field2");
		 }
		 else
		 {
			 System.out.println("Field1 not copied to Field2");
		 }
		 */
		 
		 //Drag and Drop
		 
		 WebElement source=driver.findElement(By.xpath("//p[text()='Drag me to my target']"));
		 
		 WebElement target=driver.findElement(By.xpath("//p[text()='Drop here']"));
		 Thread.sleep(4000);
		 
		 act.dragAndDrop(source, target).build().perform();
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		 
		
	/* WebElement Desktop=	driver.findElement(By.xpath("//a[text()='Desktops']"));
	
	WebElement mac=driver.findElement(By.xpath("//a[text()='Mac (1)']"));
	
	 act.moveToElement(Desktop).perform();
	 
	 
	 act.keyDown(Keys.CONTROL).click(mac).keyUp(Keys.CONTROL).perform();
	 
	 List<String> ids=new ArrayList<>(driver.getWindowHandles());
	 
	 System.out.println("WindowIS are:"+ ids);
	 
	 driver.switchTo().window(ids.get(1));
	 System.out.println("Current window ID"+ driver.getWindowHandle());
	 
	 
	Boolean opencart= driver.findElement(By.xpath("//img[@title='Your Store']")).isDisplayed();
	 
	   
	 if(opencart== true)
	 {
		 System.out.println(" Image is displayed");
	 }
	 else
	 { 
		 System.out.println("Test case Failed");
	 }
	 */
	 
	
	}

}
