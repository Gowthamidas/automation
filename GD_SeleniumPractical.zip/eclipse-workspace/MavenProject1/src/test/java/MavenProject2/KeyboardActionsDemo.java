package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class KeyboardActionsDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		
		
		WebDriver driver=new ChromeDriver();	
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://demo.opencart.com/en-gb?route=common/home");
		
		driver.manage().window().maximize();
		
		Actions act=new Actions(driver);
		
		Thread.sleep(5000);
		act.keyDown(Keys.CONTROL).keyDown(Keys.SHIFT).sendKeys("R").keyUp(Keys.SHIFT).keyUp(Keys.CONTROL).perform();
		
		 WebElement tablet=driver.findElement(By.xpath("//a[text()='Tablets']"));
		 //tablet.click();
		act.keyDown(Keys.CONTROL).click(tablet).perform();
		
	}

}
