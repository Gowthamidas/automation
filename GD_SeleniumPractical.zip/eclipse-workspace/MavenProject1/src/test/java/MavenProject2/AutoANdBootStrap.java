package MavenProject2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AutoANdBootStrap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://kforce-uat.workingllama.com/atsuser/");
		driver.manage().window().maximize();
		
		
		driver.findElement(By.xpath("(//div[@class='e-multi-select-wrapper e-down-icon'])[2]")).click();
		driver.findElement(By.xpath("//input[@class='e-input-filter e-input']")).sendKeys(".Net");
		
		
		List<WebElement> options=driver.findElements(By.xpath("//div[@class='e-content e-dropdownbase']//li"));
		System.out.println("Totla count is"+options.size());
		
		for(WebElement op:options)
		{
			String value1=op.getText();
			if(value1.equals(".Net"))
			{
				op.click();
			}
		}
		driver.close();
	}

}
