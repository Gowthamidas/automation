package MavenProject2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class StaticTable {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
	WebDriver driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
	driver.get("https://testautomationpractice.blogspot.com/");
	driver.manage().window().maximize();
	
	int rows=driver.findElements(By.xpath("//table[@name='BookTable']/tbody/tr")).size();
	
	int columns=driver.findElements(By.xpath("//table[@name='BookTable']/tbody/tr/th")).size();
	
	
	//Print all data from the static table
	/*System.out.println("BookName"+"\t"+"Author"+"\t"+"Subject"+"\t"+"Price"+"\t");
	for (int r=2;r<=rows;r++)
	{
		for(int c=1;c<=columns;c++)
		{
			String value=driver.findElement(By.xpath("//table[@name='BookTable']/tbody/tr["+r+"]/td["+c+"]")).getText();
			System.out.print("    "+value);
		}
		System.out.println("");
	}
	*/
	
	//Print the sum of prices
	int Total=0;
	for(int r=2;r<=rows;r++)
	{
	String Price=driver.findElement(By.xpath("//table[@name='BookTable']/tbody/tr["+r+"]/td[4]")).getText();
	Total=Total+Integer.parseInt(Price);
	Thread.sleep(2000);
	}
	System.out.println("Total price of the books="+Total);
	
	
	//Lowest Price of the book
	int lowestPrice= Total;
	
	for (int r=2;r<=rows;r++)
	{
			String Price=driver.findElement(By.xpath("//table[@name='BookTable']/tbody/tr["+r+"]/td[4]")).getText();
			int IntPrice = Integer.parseInt(Price);
			
			if(IntPrice<lowestPrice)
			{
			     lowestPrice=IntPrice;
			}
	
			     System.out.println("Lowest Price :"+lowestPrice);
			 	//finding lowest price bookname
			 	
			 	String Bookname=driver.findElement(By.xpath("//table[@name='BookTable']/tbody/tr["+r+"]/td[1]")).getText();
			 	   System.out.println("Lowest price book name"+Bookname);
			
	}
	
	
	
	driver.close(); 
	}

}
