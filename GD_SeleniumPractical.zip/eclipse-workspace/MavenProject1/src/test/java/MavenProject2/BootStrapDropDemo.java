package MavenProject2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class BootStrapDropDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://www.jquery-az.com/boots/demo.php?ex=63.0_2");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//button[contains(@class,'multiselect')]")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//ul//input[@value='jQuery']")).click();
		
		List<WebElement> options=driver.findElements(By.xpath("//ul[@class='multiselect-container dropdown-menu']/*"));
		
		System.out.println("Total no of options are:" +options.size());
		System.out.println("Options are:");
	  for(int i=0;i<options.size();i++)
	  {
		  System.out.println(options.get(i).getText());
		  String op2=options.get(i).getText();
		  if(op2.equals("Java") ||op2.equals("Oracle"))
				  {
			  options.get(i).click();
				  }
	  }
		
		
		driver.close();
		
	}
	
}
