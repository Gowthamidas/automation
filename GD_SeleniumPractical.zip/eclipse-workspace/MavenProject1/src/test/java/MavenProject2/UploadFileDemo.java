package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class UploadFileDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://davidwalsh.name/demo/multiple-file-upload.php");
		driver.manage().window().maximize();
		
		
	/*	driver.findElement(By.xpath("//input[@name='filesToUpload']")).sendKeys("C:\\Users\\USER\\Documents\\New folder\\Trivan.docx");
		
		if(driver.findElement(By.xpath("//ul[@id='fileList']/li")).getText().equals("Trivan.docx"))
		{
			System.out.println("File uploaded successfully");
		}
		else
		{
			System.out.println("File no uploaded");
		}
		*/
		
		String File1="C:\\Users\\USER\\Documents\\New folder\\Trivan.docx";
	    String File2="C:\\\\Users\\\\USER\\\\Documents\\\\New folder\\\\kajal.docx";
	    
	    driver.findElement(By.xpath("//input[@name='filesToUpload']")).sendKeys(File1+"\n"+File2);
		
	    
	    if(driver.findElement(By.xpath("//ul[@id='fileList']//li[1]")).getText().equals("Trivan.docx") &&
	    		driver.findElement(By.xpath("//ul[@id='fileList']//li[2]")).getText().equals("kajal.docx"))
	    		{
			System.out.println("Multiple files uploaded successfully");

	    		}
	    else
	    {
			System.out.println("Multiple files uploaded Faied");

	    }
		
	}

}
