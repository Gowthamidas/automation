package MavenProject2;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicTablewithPagination {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://testautomationpractice.blogspot.com/");
		driver.manage().window().maximize();
		
		
			int tootalpage=driver.findElements(By.xpath("//ul[@class='pagination']//li")).size();
				
	int rows=driver.findElements(By.xpath("//table[@id='productTable']//tr")).size();
	
	int cols=driver.findElements(By.xpath("//table[@id='productTable']//tr[1]/td")).size();

				System.out.println("ID"+"\t"+"Name"+"\t"+"Price");
	
	for (int i=1;i<=tootalpage;i++)
				{	
                  driver.findElement(By.xpath("//ul[@class='pagination']//li["+i+"]")).click();
					
					for(int r=1;r<=rows-1;r++)
					{
						for (int c=1;c<=cols;c++)
						{
							String value=driver.findElement(By.xpath("//table[@id='productTable']//tr["+r+"]/td["+c+"]")).getText();
							
							
					            System.out.print(""+value+"\t");
					            if(c==4)
								{
								driver.findElement(By.xpath("//table[@id='productTable']//tr["+r+"]//input[@type='checkbox']")).click();
								}
							
						}
						System.out.println("");
					}
				}
				

				
	}

}
