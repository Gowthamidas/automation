package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.MoveTargetOutOfBoundsException;

public class sliderDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://epictravelstaffing-uat.workingllama.com/atsuser/");
		driver.manage().window().maximize();
		
		
		// salry slider
	/*	driver.findElement(By.xpath("(//div[@class='card-title ml-0'])[2]")).click();
		
		WebElement min_slider=driver.findElement(By.xpath("(//input[@type='range'])[2]"));
		
		System.out.println("min_slider location"+min_slider.getLocation()); //(410, 358)
		Actions act=new Actions(driver);
		Thread.sleep(4000);
		
		act.dragAndDropBy(min_slider, 7000, 358).build().perform();
	    
		System.out.println("min_slider location"+min_slider.getLocation()); 
		*/
		
	// Miles Range
         driver.findElement(By.xpath("(//div[@class='card-title ml-0'])[1]")).click();
		
		WebElement max_slider=driver.findElement(By.xpath("(//input[@type='range'])[1]"));
		
		System.out.println("min_slider location"+max_slider.getLocation()); //(185, 361)
		Actions act=new Actions(driver);
		Thread.sleep(4000);
		
		act.dragAndDropBy(max_slider, 1000, 361);
		System.out.println("min_slider location"+max_slider.getLocation()); 
	
	
	
	
	
	
	
	}

}
