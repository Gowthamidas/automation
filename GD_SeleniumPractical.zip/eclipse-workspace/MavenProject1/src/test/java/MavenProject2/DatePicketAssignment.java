package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.ElementClickInterceptedException;

public class DatePicketAssignment {
	
	
	 static void selectDM(WebDriver driver, String year, String month) 
     {
	 WebElement Month= driver.findElement(By.xpath("//select[@aria-label='Select month']"));
	 Select mon=new Select(Month);
	 mon.selectByVisibleText("Mar");
	 
	 
	 WebElement Year= driver.findElement(By.xpath("//select[@aria-label='Select year']"));
	 Select yea=new Select(Year);
	 yea.selectByVisibleText("2026");
	 
     }

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		String expyear="2026";
		String expmonth="Mar";
		String expdate="15";

	
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://dummy-tickets.com/buyticket");
		driver.manage().window().maximize();
		driver.findElement(By.xpath("(//a[normalize-space()='Both'])[1]")).click();
		Thread.sleep(4000);
		
	//driver.findElement(By.xpath("(//input[@name='departure[]' and @placeholder='Departure Date'])[4]")).sendKeys("15-01-2025");
		
		WebElement depart=driver.findElement(By.xpath("(//input[@placeholder='Departure Date'])[4]"));
          depart.clear();
          depart.click();
          
          selectDM(driver, expyear, expmonth);
		 
		 
		//driver.close();
	}

}
