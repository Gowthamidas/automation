package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

		driver.get("https://the-internet.herokuapp.com/javascript_alerts");
		driver.manage().window().maximize();
		
		//simple alert
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Alert']")).click();
		Alert myalert=driver.switchTo().alert();
		
		myalert.accept();
		String result=driver.findElement(By.xpath("//h4[normalize-space()='Result:']/following-sibling::*")).getText();
		System.out.println("Simple alert result is:" +result);

		if(result.contains("clicked"))
				
				{ 
			      System.out.println("Simple alert Test Passed1");
				
				}
		else
		         {
			       System.out.println("Simple alert Test Failed ");
		         }
		
		
		
		
		//Confirmation alert
		/* driver.findElement(By.xpath("//button[normalize-space()='Click for JS Confirm']")).click();
		Alert myalert1=driver.switchTo().alert();
		System.out.println(" Visible text is:"+myalert1.getText());
		myalert1.dismiss();
		
		String resulttext2=driver.findElement(By.xpath("//p[@id='result']")).getText();
		if(resulttext2.contains("Cancel"))
			
		      { 
	      System.out.println("Test Passed2");
		
		      }
          else
         {
	       System.out.println("Test Failed2 ");
         }
		*/
	
		
		//Prompt alert with textbox
		driver.findElement(By.xpath("//button[normalize-space()='Click for JS Prompt']")).click();
		
		Alert myalert3=driver.switchTo().alert();
		myalert3.sendKeys("welcome");
		myalert3.accept();
		
		String resulttext3=driver.findElement(By.xpath("//p[@id='result']")).getText();

		
		 if(resulttext3.contains("welcome"))
			
	       { 
             System.out.println("Prompt alert Test Passed3");
	
	       }
         else
          {
            System.out.println("Prompt alert Test Failed3 ");
            }
		
	}
	

}
