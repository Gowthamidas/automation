package MavenProject2;

import java.io.File;
import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TakeScreenshotDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://seller.flipkart.com/sell-online?utm_source=fkwebsite&utm_medium=websitedirect/");
		driver.manage().window().maximize();
		
	//   Taking page screenshot
	/*	TakesScreenshot ts=(TakesScreenshot)driver;
		
	    File sourcefile= ts.getScreenshotAs(OutputType.FILE);
	    
	    File targetfile=new File(System.getProperty("user.dir")+"\\Screenshots\\fullPage.png");

	    sourcefile.renameTo(targetfile);
	    
	    */
		
		
		//Take particular area screenshot
		/* WebElement listProduct=driver.findElement(By.xpath("//div[@id='listProducts']"));
		File sourcefile=listProduct.getScreenshotAs(OutputType.FILE);
		
		File targetfile=new File(System.getProperty("user.dir")+"\\Screenshots\\Sectionss.png");
		
	    sourcefile.renameTo(targetfile);

		*/
		
		//Take webelement screenshot
		
		 WebElement listProduct=driver.findElement(By.xpath("//img[@class='styles__Image-sc-a90kxg-7 styles__HeaderImage-sc-1lklol6-1 biMflU']"));
	    File sourcefile=listProduct.getScreenshotAs(OutputType.FILE);
				
    	File targetfile=new File(System.getProperty("user.dir")+"\\Screenshots\\elementss.png");
	      sourcefile.renameTo(targetfile);
	      
	      
		
	    //driver.close();
	}

}
