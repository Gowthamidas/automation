package MavenProject2;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.SessionNotCreatedException;

public class OptionsClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ChromeOptions options=new ChromeOptions();
		
 //Headless testing
		//options.addArguments("--headless=new");  // setting for headless mode of execution
		options.addArguments("--incognito");  //opening in incognito mode
		//options.setExperimentalOption("executeSwitches", new String[] {"enable-automation"}); 

		//System.out.println(options.getBrowserName());

		
		WebDriver driver=new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://flipkart.com/");
		driver.manage().window().maximize();
		System.out.println(driver.getTitle());
		
   //Handling ssl
		/* options.setAcceptInsecureCerts(true);   //ssl set true to bypass
		
		WebDriver driver=new ChromeDriver(options);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://expired.badssl.com/");
		driver.manage().window().maximize();
		System.out.println("Title"+driver.getTitle());
		*/
	}

}
