package DataDrivenDemo;

import java.io.FileOutputStream;
import java.io.IOException;


import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteDataIntoExcelDemo {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		

		
		XSSFWorkbook workbook=new XSSFWorkbook();
		
		XSSFSheet sheet=workbook.createSheet("Data");
		
		XSSFRow row1=sheet.createRow(0);
		row1.createCell(0).setCellValue("Java");
		row1.createCell(1).setCellValue(1);
		row1.createCell(2).setCellValue("Automation");
		
		
		XSSFRow row2=sheet.createRow(1);
		row2.createCell(0).setCellValue("python");
		row2.createCell(1).setCellValue(2);
		row2.createCell(2).setCellValue("Automation");
		
	
		
		/* XSSFRow row1=sheet.createRow(3);
		XSSFCell cell=row1.createCell(4);
		cell.setCellValue("welcome");
		*/
		
		FileOutputStream file=new FileOutputStream("C:\\Users\\USER\\eclipse-workspace\\MavenProject1\\testdata\\WriteData.xlsx");
		
		workbook.write(file);
		workbook.close();
		file.close();
    System.out.println("File created");
		
	}

}
