package TNGAnnotations;

import org.testng.annotations.*;

public class Annotation2 {
	
	
	@Test
	void testprint()
	{
		System.out.println("Print executed3");
	}
	
	@BeforeSuite
	void testsuitea()
	{
		System.out.println("Before suite executed");
	}
	
	@AfterClass
	void testsuitac()
	{
		System.out.println("After class2 executed");
	}
	
	@AfterSuite
	void testsuiteb()
	{
		System.out.println("After Suite executed");
		
	}
	@AfterTest
	void testafterT()
	{
		System.out.println("After test executed");
		
	}

}
