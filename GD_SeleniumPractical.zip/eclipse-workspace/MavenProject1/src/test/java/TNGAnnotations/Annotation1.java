package TNGAnnotations;

import org.testng.annotations.*;

public class Annotation1 {
	
	@Test(priority=20)
	void testab()
	{
		System.out.println("Test executed1");
	}
	
	@Test(priority=-4)
	void testcd()
	{
		System.out.println("Test executed2");
	}
	
	@BeforeMethod
	void testbm()
	{
		System.out.println("Before method executed");
		
	}
	
	
	@AfterMethod
	void testam()
	{
		System.out.println("After method executed");
	}

	@BeforeClass
	void testbc()
	{
		System.out.println("Before class executed");
	}
	
	@AfterClass
	void testac()
	{
		System.out.println("After class executed");
	}
}
