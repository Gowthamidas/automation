package TesNGParam;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.*;

public class DataProvideDemo {
	WebDriver driver;
	

	@Test(dataProvider="dp")
	void testlogin(String email, String pswd)
	{
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	    driver.manage().window().maximize();
		
		

		driver.findElement(By.name("username")).sendKeys(email);
		driver.findElement(By.name("password")).sendKeys(pswd);
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
	   
	}
	
	@Test(priority=2)
	void testlogo()
	{
		boolean logo=driver.findElement(By.xpath("//img[@alt='client brand banner']")).isDisplayed();
		Assert.assertEquals(logo, true);
	}
	
	@AfterClass
	void teardown()
	{
		driver.quit();
	}
	
	
	@DataProvider(name="dp")
	Object[] testData()
	{
		Object data[][]= {
				            {"test","test123"},
			               	{"admin","admin123"},
			            	{"GDtest","test123"},
				  
		                 };
		return data;
	}

}
