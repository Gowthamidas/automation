package TesNGParam;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.*;

public class ParallerTestingDemo {
	
	WebDriver driver;
	
	
	@BeforeClass
	@Parameters({"browser"})
	void setup(String br)
	{
		switch (br.toLowerCase())
		{
		case "chrome": driver=new ChromeDriver();
			                break;
			case "edge" : driver=new EdgeDriver();
                            break;
			case "firefox" : driver=new FirefoxDriver();
                            break;
            default : System.out.println("Invalid browser");
                              return;
		}
	}
	
	
	



	@Test
	void testlogin()
	{
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	    driver.manage().window().maximize();
		
		

		driver.findElement(By.name("username")).sendKeys("admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		
	   
	}

}
