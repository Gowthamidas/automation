package MavenPackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ElementClickInterceptedException;

public class RadiobuttonDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		driver.manage().window().maximize();
		driver.get("https://practice.expandtesting.com/radio-buttons#google_vignette");
		
		driver.manage().window().maximize();
		
		WebElement red=driver.findElement(By.xpath("//input[@id='red']"));
		red.click();
		System.out.println("Red Radio button status is:"+ red.isSelected());
		
		boolean tennis_status=driver.findElement(By.xpath("//input[@id='tennis']")).isSelected();
		System.out.println("Status of Tennis Radio button by default is:"+ tennis_status);
		
		driver.quit();
	}

}
