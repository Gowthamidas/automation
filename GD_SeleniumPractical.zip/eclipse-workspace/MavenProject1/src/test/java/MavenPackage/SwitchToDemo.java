package MavenPackage;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SwitchToDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		 WebDriver driver=new ChromeDriver();
		 driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		 String url="https://testautomationpractice.blogspot.com/";
		 driver.get(url);
		 
		 
		 driver.manage().window().maximize();
		 
		 driver.findElement(By.xpath("//a[normalize-space()='merrymoonmary']")).click();
		 
		Set<String> windowIDs=driver.getWindowHandles();
		
	//	Approach1
		//List<String> winID=new ArrayList<>(windowIDs);
		  //   String parentid=winID.get(0);
		    // System.out.println("ParentPage ID is:"+parentid);
		   //  String childid=winID.get(1);
		    // System.out.println("ChildPage ID is:"+childid);

		    // driver.switchTo().window(childid);
		   //  System.out.println(driver.getTitle());
		   	//driver.close();
		
		//Approach2
		for(String winid:windowIDs)
		{
			String ChildTitle=driver.switchTo().window(winid).getTitle();
			
			if(ChildTitle.equals("merrymoonmary Stock Image and Video Portfolio - iStock"))
			{
				driver.close();
				break;
			}
		}
		    

	}

}
