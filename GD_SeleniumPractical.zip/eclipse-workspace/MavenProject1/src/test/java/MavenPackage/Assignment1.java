package MavenPackage;

import java.time.Duration;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment1 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
		
		WebDriver driver=new ChromeDriver();
		
		driver.get("https://testautomationpractice.blogspot.com/");
		
		driver.manage().window().maximize();
		
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		WebElement search=driver.findElement(By.xpath("//input[@id='Wikipedia1_wikipedia-search-input']"));
	
		search.sendKeys("TestCricket");
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		
		List<WebElement> searchResults=driver.findElements(By.xpath("//div[@id='Wikipedia1_wikipedia-search-results']/descendant::a"));
		

		System.out.println("Search Result total count is:"+searchResults.size());
		
		for(WebElement Links:searchResults)
		{
			Links.click();
			//Thread.sleep(5000);
		}
		
               Set<String> winID=driver.getWindowHandles();
               System.out.println("WindowIDs are:" +winID);
               boolean status=false;
               
               for(String wid:winID)
               {
            	  
                      String title=driver.switchTo().window(wid).getTitle();
                      if(title.equals("ICC Men's Test Team Rankings - Wikipedia"))
                      {
                    	  System.out.println(driver.getCurrentUrl());
                    	   status=true;
                      }
                     
               }
               if (status == false)
               {
            	   System.out.println("Title not matched");
               }
               driver.quit();
	}

}
