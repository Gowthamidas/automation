package MavenPackage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * 
 */
public class MenthodsDec26 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
            WebDriver driver=new ChromeDriver();
            driver.get("https://testautomationpractice.blogspot.com/");
            driver.manage().window().maximize();
            System.out.println("Wondow ID:  "+driver.getWindowHandle());
            
            System.out.println("Title is:  "+driver.getTitle());
    
            

            
            Thread.sleep(3000);
            
            WebElement name=driver.findElement(By.xpath("//input[@id='name']"));
            name.click();
            name.sendKeys("Gowthami");
            
           WebElement smartphone=driver.findElement(By.xpath("(//input[@type='checkbox'])[8]"));
           smartphone.click();
           Thread.sleep(5000);
           boolean status=smartphone.isSelected();
           System.out.println("status of smartphon enablement:"+status );
           
          driver.findElement(By.xpath("//a[normalize-space()='merrymoonmary']")).click();
           
          Thread.sleep(3000);
           System.out.println("Wondows IDs are:"+driver.getWindowHandles());
        	System.out.println("Current URl"+driver.getCurrentUrl());
           driver.close();
	}

}
