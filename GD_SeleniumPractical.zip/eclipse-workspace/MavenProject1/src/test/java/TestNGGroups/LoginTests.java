package TestNGGroups;

import org.testng.annotations.Test;

public class LoginTests {

	@Test(priority=1, groups= {"Sanity"})
	void loginBygoogle()
	{
		System.out.println("Logged in by email");
	}
	
	@Test(priority=2, groups= {"Sanity"})
	void google()
	{
		System.out.println("Logged in by google");
	}
	
	@Test(priority=3, groups= {"Sanity"})
	void loginByFacebook()
	{
		System.out.println("Logged in by FB");
	}
}
