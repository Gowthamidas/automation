package TestNGGroups;

import org.testng.annotations.Test;

public class PaymentTests {

	@Test(priority=1, groups={"Sanity","regression","functional"})
	void PayemntRupee()
	{
		System.out.println("Payment in rupees");
	}
	@Test(priority=2, groups={"Sanity","regression","functional"})
	void PaymentDollars()
	{
		System.out.println("Payment in Dollars");
	}
}
