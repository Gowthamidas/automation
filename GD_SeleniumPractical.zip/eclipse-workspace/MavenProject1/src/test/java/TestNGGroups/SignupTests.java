package TestNGGroups;

import org.testng.annotations.Test;

public class SignupTests {
	
	
	@Test(priority=1, groups= {"regression"})
	void signupBygoogle()
	{
		System.out.println("signup by google");
	}
	
	@Test(priority=2, groups= {"regression"})
	void signupbyemail()
	{
		System.out.println("signup by email");
	}
	
	@Test(priority=3, groups= {"regression"})
	void SignupByFacebook()
	{
		System.out.println("signup by FB");
	}

}
