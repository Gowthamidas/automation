package TNGPackage;

import org.testng.Assert;
import org.testng.annotations.*;

public class Assertiondemo {
	
	@Test
	void testexecute()
	{
	    String exp_result="Testing";
	    String act_result="Test123";
	    
	    if(exp_result.equals(act_result))
	    {
	    	
	    	System.out.println("Test Passed");
	    	Assert.assertTrue(true);
	    }
	    else
	    {
	    	System.out.println("Test Failed");
	    	Assert.assertTrue(false);
	    }
	  
	    //Assert.assertEquals(exp_result, act_result);
	}

}
