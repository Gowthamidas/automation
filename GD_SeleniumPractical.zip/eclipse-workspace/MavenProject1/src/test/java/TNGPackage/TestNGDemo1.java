package TNGPackage;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TestNGDemo1 {
	WebDriver driver;
	
	@Test(priority=1)
	void  launch()
	{
		driver= new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		driver.manage().window().maximize();
	}
	
	@Test(priority=2)
	void logo() throws InterruptedException
	{  Thread.sleep(5000);
		 boolean logo=driver.findElement(By.xpath("//img[@alt='company-branding']")).isDisplayed();
	     System.out.println("Logo status is"+logo);
	}
	
	@Test(priority=3)
	void login()
	 {
		 driver.findElement(By.xpath("//label[text()='Username']")).sendKeys("admin");
		 driver.findElement(By.xpath("//label[text()='Password']")).sendKeys("admin123");
	      driver.findElement(By.xpath("//button[@type='submit']")).click();
	 }
	
	@Test(priority=4)
	void logout()
	 {
		driver.close();
		  
	  }

}
