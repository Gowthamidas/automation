package TNGPackage;

import org.testng.annotations.Test;

public class Jan13program {
	
	
	
	@Test
	void login()
	{
	System.out.println("loggin to app");
	}
	
	@Test
	void logout()
	{
	System.out.println("Logout from the app");
	}
	
	@Test(priority=-7)
	void openapp()
	{
	System.out.println("Opening the app");
	}
		
}
