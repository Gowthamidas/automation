package TNGPackage;

import org.testng.Assert;
import org.testng.annotations.Test;

public class DependencyClassDemo {

	@Test(priority=1)
	void openapp()
	{
		Assert.assertEquals(123, 123);
	}
	
	@Test(priority=2, dependsOnMethods= {"openapp"})
	void login()
	{
		Assert.assertTrue(false);
	}
	
	@Test(priority=3, dependsOnMethods= {"openapp","login"})
	void search()
	{
		System.out.println("search function");	
	}
	
	
	@Test(priority=4)
	void adserach()
	{
		System.out.println("advanced serach function");
	}
	
	@Test(priority=5)
	void logout()
	{
		System.out.println("logout from the app");
	}
}
