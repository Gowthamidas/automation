package TNGPackage;

import org.testng.Assert;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

public class HardvsSoftAssertion {
	
	@Test
	void testprint()
	{
		/*
		 System.out.println("Testing");
		Assert.assertEquals(123, 345);
		System.out.println("Testing1");
		System.out.println("Testing2");
		*/
		
		System.out.println("Testing");
		SoftAssert sa=new SoftAssert();
		sa.assertEquals(123, 345);
		
		System.out.println("Testing1");
		System.out.println("Testing2");
		sa.assertAll();
	}

}
