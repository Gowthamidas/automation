package SupraHealthPackage;

import java.time.Duration;
import java.util.NoSuchElementException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;
import org.testng.asserts.SoftAssert;

/*
 * Access TP  
 * verify widget availability & its placeholder text and switch to it
 * 
 */

public class AppointmentSchedulingDemo {
	  WebDriver driver;
	  Actions act;
	  SoftAssert sa;
	  WebDriverWait wait;
	  
          @BeforeClass
          void setup()
          {
        	  driver=new ChromeDriver();
        	  driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        	  
        	  driver.get("https://suprahealth.workllama.com/atsuser/");
        	  driver.manage().window().maximize();
          }
          
        	 @Test(priority=1)
        	 void widgetAccess()
        	 {
        		 sa=new SoftAssert();
        		 	 
        		wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        	 WebElement bubbleText = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id='chatBubble']")));        
        		 
        	 sa.assertEquals(bubbleText.getText(), "How may I help you today?", "Bubble text does not match expected value.");


                 
        		//widget click
        	 WebElement widget = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='wl-chat-button']")));
        		 
        	      if(widget.isEnabled())
        	         {
        		       widget.click();
        	          }
        	       else
        	           {
        		    System.out.println("Widget is not enabled in the Portal");       
        	           }
        	     
                 sa.assertAll();
        		
        	     
        	 }
        	  
        	 
        	@Test(priority=2, dependsOnMethods={"widgetAccess"})
        	 void uiValidation() 
        	 {
        		 
        		 //sofi UI Validation
        		
        		driver.switchTo().frame(0);

        		 FluentWait<WebDriver> fluentWait = new FluentWait<>(driver)
        		            .withTimeout(Duration.ofSeconds(20))
        		            .pollingEvery(Duration.ofSeconds(4))
        		            .ignoring(NoSuchElementException.class);

                // Wait for logo to be visible
        		    WebElement logo = fluentWait.until(driver -> driver.findElement(By.xpath("//img[@class='rounded-circle user_img']")));
        		    sa.assertTrue(logo.isDisplayed(), "Logo is not displayed!");
        		
        	   
        		        	
        		 
        		//restart the conversation
        		    WebElement restart = fluentWait.until(driver -> driver.findElement(By.xpath("//div[@class='foot']")));
        		    sa.assertTrue(restart.isEnabled(), "Restart conversation enabled");
        		    
        		    
        	    
        		    
        		 sa.assertAll(); 
        	 }
             
          
            

         @AfterClass
          void tearDown()
         {
            driver.quit();
         }

          
          
}
